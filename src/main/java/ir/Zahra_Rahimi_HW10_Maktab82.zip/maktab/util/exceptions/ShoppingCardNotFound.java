package ir.maktab.util.exceptions;

public class ShoppingCardNotFound extends Exception {

    public ShoppingCardNotFound(String s) {
        super(s);
    }
}
