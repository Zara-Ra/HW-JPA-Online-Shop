package ir.maktab.util.exceptions;

public class ValidationException extends Exception{
    public ValidationException(String message) {
        super(message);
    }
}
