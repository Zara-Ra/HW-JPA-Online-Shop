package ir.maktab.util.exceptions;

public class ShoppingCardExcepiton extends Exception {
    public ShoppingCardExcepiton(String message) {
        super(message);
    }
}
