package ir.maktab.presentation;

public class Main {
    public static void main(String[] args) {
        OnlineShop onlineShop = new OnlineShop();
        onlineShop.welcome();
    }
}
