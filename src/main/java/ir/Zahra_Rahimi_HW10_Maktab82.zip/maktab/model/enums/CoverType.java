package ir.maktab.model.enums;

public enum CoverType {
    SOFT,
    HARD
}
