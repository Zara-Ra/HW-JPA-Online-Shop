package ir.maktab.model.enums;

public enum Gender {
    MALE,
    FEMALE,
    UNISEX
}
