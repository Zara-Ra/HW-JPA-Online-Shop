package ir.maktab.model.enums;

public enum CasualType {
    SPORTS,
    WALKING,
    SANDAL
}
