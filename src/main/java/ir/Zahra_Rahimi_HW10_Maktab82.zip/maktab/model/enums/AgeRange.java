package ir.maktab.model.enums;

public enum AgeRange {
    ADULT,
    TEEN,
    CHILD,
    PRESCHOOL
}
