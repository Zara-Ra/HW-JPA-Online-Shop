package ir.maktab.model.enums;

public enum ConfirmStatus {
    CONFIRMED,
    PENDING,
    DELETE;
}
