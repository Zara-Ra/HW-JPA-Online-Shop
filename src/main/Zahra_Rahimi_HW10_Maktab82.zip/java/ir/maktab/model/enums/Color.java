package ir.maktab.model.enums;

public enum Color {
    RED,
    BLUE,
    GREEN,
    YELLOW,
    BLACK,
    WHITE,
    BROWN
}
