package ir.maktab.util.exceptions;

public class UserNotSignedUpException extends Exception {
    public UserNotSignedUpException(String message) {
        super(message);
    }
}
