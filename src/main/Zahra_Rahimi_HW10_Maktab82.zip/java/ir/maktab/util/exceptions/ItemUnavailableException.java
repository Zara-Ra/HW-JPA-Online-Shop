package ir.maktab.util.exceptions;

public class ItemUnavailableException extends Exception {
    public ItemUnavailableException(String message) {
        super(message);
    }
}
