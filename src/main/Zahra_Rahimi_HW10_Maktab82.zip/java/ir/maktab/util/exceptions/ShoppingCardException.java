package ir.maktab.util.exceptions;

public class ShoppingCardException extends Exception {
    public ShoppingCardException(String message) {
        super(message);
    }
}
